import java.io.*;
import java.net.*;

/*--------------------------------------------------------

1. Michael Crabtree / 6/28/20:

2. java version "14.0.1" 2020-04-14

3.: To compile run cmd lines

> javac JokeServer.java
> javac JokeClient.java
> javac JokeClientAdmin.java

I added extra classes but I put them in all the java files that need them
You shouldn't have to run in that order but thats the only order I confirmed to work

4. How to run:

> java JokeServer
run server on primary port 4545

> java JokeServer <secondary>
If the literal string "secondary" is inputted as argument the server will run on the secondary port 4546

> java JokeClient
Run JokeClient and default the server to connect to to localhost on port 4545

> java JokeClient <primaryServerName>
Run JokeClient and with the server to connect to being the input <primaryServerName> on port 4545

> java JokeClient <primaryServerName> <secondaryServerName>
Run JokeClient and with the primary server to connect to being the input <primaryServerName> on port 4545
And the secondary server being the input <secondaryServerName> on port 4546

> java JokeClientAdmin
Run JokeClientAdmin and default the server to connect to to localhost on port 5050

> java JokeClientAdmin <primaryServerName>
Run JokeClientAdmin and with the server to connect to being the input <primaryServerName> on port 5050

> java JokeClientAdmin <primaryServerName> <secondaryServerName>
Run JokeClientAdmin and with the primary server to connect to being the input <primaryServerName> on port 5050
And the secondary server being the input <secondaryServerName> on port 5051


5. File needed to run

 Required
 a. JokeServer.java
 b. JokeClient.java

 Optional to switch modes between Joke and Proverb
 JokeClientAdmin.java

----------------------------------------------------------*/
public class JokeClientAdmin {
    public static Server currentServer;
    public static Server primaryServer;
    public static Server secondaryServer;
    public static void main (String args[]) {
        String primaryServerName;
        String secondaryServerName = null;

        // check for cmd line arguments
        // if none default to localhost
        if (args.length < 1) {
            primaryServerName = "localhost";
        } else { // if cmd line arg exists, use it for server name
            primaryServerName = args[0];
            if(args.length == 2) secondaryServerName = args[1];
        }
        
        //set primary server
        primaryServer = new Server(primaryServerName, 5050);

        //current server defaults to primary
        currentServer = primaryServer;

        System.out.println("Michael Crabtree's Joke Admin Client, 1.8.\n");
        System.out.println("Server one: " + primaryServer.getName() + ", port " + primaryServer.getPort());

        //if second server was inputted set it
        if(secondaryServerName != null) {
            secondaryServer = new Server(secondaryServerName, 5051);
            System.out.println("Server two: " + secondaryServer.getName() + ", port " + secondaryServer.getPort());
        }
        System.out.println("Now communicating with: " + currentServer.getName() + ", port " + currentServer.getPort());

        //set up buffer for reading input
        BufferedReader inputReader = new BufferedReader(new InputStreamReader(System.in));

        try {
            //first get the current state of the server mode
            sendInputToServer("GET");
            String input;
            //loop infinitely until quit input is entered
            while(true) {
                // output instruction for user
                System.out.print("Press enter to change the mode of the Server: <type 'quit' to exit> ");
                System.out.flush();
                // wait for user to press enter
                input = inputReader.readLine();
                //immediately leave loop on quit
                if(input == null || input.equals("quit")) break;
                //toggle server if there is a second server and the command is "s"
                if(secondaryServerName != null && input.equals("s")) {
                    toggleServer();
                    //get state of new server after change
                    sendInputToServer("GET");
                } else {
                    // change the state of the server mode
                    sendInputToServer("PUT");
                } 
            }

            System.out.println ("\nCancelled by user request.");
        } catch (IOException e) {
            //print error
            e.printStackTrace();
        }
    }

   // change to the other server name
   public static void toggleServer() {
    if(currentServer == primaryServer) {
        currentServer = secondaryServer;
        System.out.println("Now communicating with: " + currentServer.getName() + ", port " + currentServer.getPort());
    } else {
        currentServer = primaryServer;
        System.out.println("Now communicating with: " + currentServer.getName() + ", port " + currentServer.getPort());
    }
}

    /*
     *   @param method string to send to server that determines whether the server will get the cuurent state or change the state
     *   @param address location of our server
    */
    static void sendInputToServer (String method) {
        Socket socket;
        BufferedReader fromServer;
        PrintStream toServer;
        String result;

        try{
            //open socket to serverName at port 5050
            socket = new Socket(currentServer.getName(), currentServer.getPort());

            // set up buffers to get and send data to server 
            fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            toServer = new PrintStream(socket.getOutputStream());

            // send command to server of which action to run
            toServer.println(method);
            toServer.flush();

            // print server result
            result = fromServer.readLine();
            if (result != null) {
                System.out.println(result);
            }
            // close socket after done with getting input
            socket.close();
        } catch (IOException e) {
            System.out.println ("Socket error.");
            e.printStackTrace();
        }
    }
}

    // class to store server data to make it easy to switch servers
    class Server {
        // server name
        private String name;
        // server port number
        private Integer port;

        //set uuid on construct
        public Server(String name, Integer port) {
            this.name = name;
            this.port = port;
        }

        public String getName() {
            return name;
        }

        public Integer getPort() {
            return port;
        }
    }